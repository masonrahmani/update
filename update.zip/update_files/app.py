import os
import zipfile
import shutil
import filecmp
from flask import Flask, render_template, request

app = Flask(__name__)

# Define your current app version
current_app_version = "1.0"

@app.route('/')
def index():
    return render_template('upload.html')


def copy_files(source_dir, destination_dir):
    for root, dirs, files in os.walk(source_dir):
        for file_name in files:
            source_file = os.path.join(root, file_name)
            relative_path = os.path.relpath(source_file, source_dir)
            destination_file = os.path.join(destination_dir, relative_path)
            
            os.makedirs(os.path.dirname(destination_file), exist_ok=True)
            
            # Check if the destination file exists and has the same content
            if os.path.exists(destination_file) and filecmp.cmp(source_file, destination_file):
                continue  # Skip copying if file is already present and not modified
            
            shutil.copyfile(source_file, destination_file)

@app.route('/apply_update', methods=['POST'])
def apply_update():
    if 'update_file' not in request.files:
        return "No file part"

    update_file = request.files['update_file']

    if update_file.filename == '':
        return "No selected file"

    if update_file:
        # Extract update files to a temporary location
        temp_dir = 'temp_update'
        os.makedirs(temp_dir, exist_ok=True)
        update_file_path = os.path.join(temp_dir, 'update.zip')
        update_file.save(update_file_path)
        with zipfile.ZipFile(update_file_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)

        # Check compatibility by reading version from the update
        with open(os.path.join(temp_dir, 'version.txt'), 'r') as version_file:
            new_version = version_file.read().strip()
        
                # Convert version strings to tuples for comparison
        current_version_tuple = tuple(map(int, current_app_version.split('.')))
        new_version_tuple = tuple(map(int, new_version.split('.')))
        if new_version_tuple <= current_version_tuple:
            return "Update version is not compatible"

        # Apply the update (replace files)
        update_files_dir = os.path.join(temp_dir, 'update_files')
        destination_dir = os.getcwd()  # Current working directory
        copy_files(update_files_dir, destination_dir)

        # Clean up temporary files
        os.remove(update_file_path)
        shutil.rmtree(temp_dir)

        return "Update successful"

    return "Error applying update"

if __name__ == '__main__':
    app.run(debug=True)